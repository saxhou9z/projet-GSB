<?php
require_once __DIR__ . '/config.php';

$page = $_GET['page'] ?? 'dashboard';

if ($page !== 'login') {
    requireLogin();
}

$user = getCurrentUser(); 
$nbRendezVous = 0;
$nbProfessionnels = 0;
$nbMedicaments = 0;
$tauxVisite = 0;
$rendezVous = [];

$basePath = __DIR__ . '/../src/vue/';
if (in_array($page, ['login', 'logout', 'rendez_vous', 'medicaments'])) {
    if (file_exists($basePath . $page . '.php')) {
        require_once $basePath . $page . '.php';
        exit;
    }
}

if ($user) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM rendez_vous WHERE utilisateur_id = ? AND statut = 'planifié'");
        $stmt->execute([$_SESSION['user_id']]);
        $nbRendezVous = $stmt->fetchColumn() ?: 0;

        $nbProfessionnels = $pdo->query("SELECT COUNT(*) FROM professionnels")->fetchColumn() ?: 0;
        $nbMedicaments = $pdo->query("SELECT COUNT(*) FROM medicaments")->fetchColumn() ?: 0;

        $stmt = $pdo->prepare("
            SELECT 
                (SELECT COUNT(*) FROM rendez_vous WHERE utilisateur_id = ? AND statut = 'effectué') as effectues,
                (SELECT COUNT(*) FROM rendez_vous WHERE utilisateur_id = ?) as total
        ");
        $stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
        $stats = $stmt->fetch();
        $tauxVisite = ($stats['total'] > 0) ? round(($stats['effectues'] / $stats['total']) * 100) : 0;

        $stmt = $pdo->prepare("
            SELECT r.*, p.nom, p.prenom, p.metier 
            FROM rendez_vous r
            JOIN professionnels p ON r.professionnel_id = p.id
            WHERE r.utilisateur_id = ? AND r.statut = 'planifié' AND r.date_rdv >= NOW()
            ORDER BY r.date_rdv ASC LIMIT 5
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $rendezVous = $stmt->fetchAll() ?: [];
    } catch (Exception $e) {
        error_log($e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>Dashboard - Visiteur Médical</title>
</head>
<body>
    <div class="container">
        <header>
            <h1>Dashboard Visiteur Médical</h1>
            <div class="user-info">
                <div class="avatar">
                    <?= strtoupper(substr($user['prenom'] ?? 'U', 0, 1) . substr($user['nom'] ?? 'N', 0, 1)) ?>
                </div>
                <div>
                    <strong><?= htmlspecialchars(($user['prenom'] ?? 'Utilisateur') . ' ' . ($user['nom'] ?? '')) ?></strong>
                    <div class="user-role">Visiteur médical</div>
                </div>
                <a href="index.php?page=logout" class="btn btn-logout">Déconnexion</a>
            </div>
        </header>

        <div class="stats-grid">
            <div class="stat-card"><h3>Rendez-vous</h3><div class="value"><?= $nbRendezVous ?></div></div>
            <div class="stat-card"><h3>Professionnels</h3><div class="value"><?= $nbProfessionnels ?></div></div>
            <div class="stat-card"><h3>Médicaments</h3><div class="value"><?= $nbMedicaments ?></div></div>
            <div class="stat-card"><h3>Taux visite</h3><div class="value"><?= $tauxVisite ?>%</div></div>
        </div>

        <main>
            <section>
                <h2>Agenda</h2>
                <div class="agenda">
                    <?php if (!empty($rendezVous)): ?>
                        <?php foreach ($rendezVous as $rdv): ?>
                            <div class="event">
                                📅 <?= date('d/m/Y H:i', strtotime($rdv['date_rdv'])) ?> - Dr. <?= htmlspecialchars($rdv['nom']) ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="color: #666;">Aucun rendez-vous planifié</p>
                    <?php endif; ?>
                </div>
                <div style="margin-top:10px; display:flex; gap:10px;">
                    <a href="index.php?page=rendez_vous" class="btn">Gérer les rendez-vous</a>
                    <a href="index.php?page=medicaments" class="btn">Gérer les médicaments</a>
                </div>
            </section>
        </main>
    </div>
</body>
</html>