<?php
require_once 'config.php';
requireLogin();

$message = '';
$messageType = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $code = $_POST['code'] ?? '';
        $designation = $_POST['designation'] ?? '';
        $prix = $_POST['prix'] ?? '';
        $description = $_POST['description'] ?? '';
        
        if (!empty($code) && !empty($designation) && !empty($prix)) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO medicaments (code, designation, prix, description) 
                    VALUES (?, ?, ?, ?)
                ");
                if ($stmt->execute([$code, $designation, $prix, $description])) {
                    $message = 'Médicament ajouté avec succès';
                    $messageType = 'success';
                }
            } catch (PDOException $e) {
                $message = 'Erreur: Le code existe déjà';
                $messageType = 'error';
            }
        } else {
            $message = 'Veuillez remplir tous les champs obligatoires';
            $messageType = 'error';
        }
    } 
    elseif ($action === 'update') {
        $id = $_POST['id'] ?? '';
        $code = $_POST['code'] ?? '';
        $designation = $_POST['designation'] ?? '';
        $prix = $_POST['prix'] ?? '';
        $description = $_POST['description'] ?? '';
        
        if (!empty($id) && !empty($code) && !empty($designation) && !empty($prix)) {
            try {
                $stmt = $pdo->prepare("
                    UPDATE medicaments 
                    SET code = ?, designation = ?, prix = ?, description = ?
                    WHERE id = ?
                ");
                if ($stmt->execute([$code, $designation, $prix, $description, $id])) {
                    $message = 'Médicament modifié avec succès';
                    $messageType = 'success';
                }
            } catch (PDOException $e) {
                $message = 'Erreur lors de la modification';
                $messageType = 'error';
            }
        }
    }
    elseif ($action === 'delete') {
        $id = $_POST['id'] ?? '';
        
        if (!empty($id)) {
            $stmt = $pdo->prepare("DELETE FROM medicaments WHERE id = ?");
            if ($stmt->execute([$id])) {
                $message = 'Médicament supprimé';
                $messageType = 'success';
            }
        }
    }
}


$medicaments = $pdo->query("SELECT * FROM medicaments ORDER BY designation")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Médicaments</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Gestion des Médicaments</h1>
            <div class="user-info">
                <a href="index.php" class="btn btn-logout">← Retour au dashboard</a>
            </div>
        </header>

        <main>
            <section class="full-width">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h2>Liste des Médicaments</h2>
                    <div style="display: flex; gap: 1rem; align-items: center;">
                        <div class="search-box">
                            <input type="text" id="searchMed" onkeyup="filterMedicaments()" 
                                   placeholder=" Rechercher...">
                        </div>
                        <button class="btn-add" onclick="openAddModal()">
                             Ajouter un médicament
                        </button>
                    </div>
                </div>
                
                <?php if ($message): ?>
                    <div class="message <?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
                <?php endif; ?>
                
                <table id="medTable">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Désignation</th>
                            <th>Prix</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($medicaments as $med): ?>
                            <tr>
                                <td><span class="badge"><?= htmlspecialchars($med['code']) ?></span></td>
                                <td><strong><?= htmlspecialchars($med['designation']) ?></strong></td>
                                <td class="price"><?= number_format($med['prix'], 2, ',', ' ') ?> €</td>
                                <td><?= htmlspecialchars($med['description'] ?? '-') ?></td>
                                <td>
                                    <div class="actions">
                                        <button class="btn-small btn-edit" 
                                                onclick='openEditModal(<?= json_encode($med) ?>)'>
                                             Modifier
                                        </button>
                                        <form method="POST" style="display: inline;" 
                                              onsubmit="return confirm('Supprimer ce médicament ?')">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?= $med['id'] ?>">
                                            <button type="submit" class="btn-small btn-danger">
                                                 Supprimer
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (count($medicaments) === 0): ?>
                            <tr>
                                <td colspan="5" style="text-align: center; color: #666;">
                                    Aucun médicament enregistré
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <!-- Modal Ajout -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3> Ajouter un médicament</h3>
                <button class="close-btn" onclick="closeModal('addModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="form-group">
                        <label for="code">Code *</label>
                        <input type="text" id="code" name="code" required 
                               placeholder="Ex: MED004">
                    </div>
                    
                    <div class="form-group">
                        <label for="designation">Désignation *</label>
                        <input type="text" id="designation" name="designation" required 
                               placeholder="Ex: Doliprane 1000mg">
                    </div>
                    
                    <div class="form-group">
                        <label for="prix">Prix (€) *</label>
                        <input type="number" id="prix" name="prix" step="0.01" required 
                               placeholder="Ex: 5.50">
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" 
                                  placeholder="Description du médicament..."></textarea>
                    </div>
                    
                    <button type="submit" class="btn-primary">Ajouter</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Modification -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3> Modifier le médicament</h3>
                <button class="close-btn" onclick="closeModal('editModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" id="edit_id" name="id">
                    
                    <div class="form-group">
                        <label for="edit_code">Code *</label>
                        <input type="text" id="edit_code" name="code" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_designation">Désignation *</label>
                        <input type="text" id="edit_designation" name="designation" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_prix">Prix (€) *</label>
                        <input type="number" id="edit_prix" name="prix" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_description">Description</label>
                        <textarea id="edit_description" name="description"></textarea>
                    </div>
                    
                    <button type="submit" class="btn-primary">Enregistrer les modifications</button>
                </form>
            </div>
        </div>
    </div>

    <script>

        function filterMedicaments() {
            let input = document.getElementById("searchMed");
            let filter = input.value.toUpperCase();
            let table = document.getElementById("medTable");
            let tr = table.getElementsByTagName("tr");

            for (let i = 1; i < tr.length; i++) {
                let tds = tr[i].getElementsByTagName("td");
                let found = false;
                
                for (let j = 0; j < tds.length - 1; j++) {
                    if (tds[j]) {
                        let txtValue = tds[j].textContent || tds[j].innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            found = true;
                            break;
                        }
                    }
                }
                
                tr[i].style.display = found ? "" : "none";
            }
        }


        function openAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }

        function openEditModal(med) {
            document.getElementById('edit_id').value = med.id;
            document.getElementById('edit_code').value = med.code;
            document.getElementById('edit_designation').value = med.designation;
            document.getElementById('edit_prix').value = med.prix;
            document.getElementById('edit_description').value = med.description || '';
            document.getElementById('editModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>