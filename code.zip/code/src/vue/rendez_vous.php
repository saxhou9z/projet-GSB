<?php
require_once 'config.php';
requireLogin();

$message = '';
$messageType = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $professionnel_id = $_POST['professionnel_id'] ?? '';
        $date_rdv = $_POST['date_rdv'] ?? '';
        $notes = $_POST['notes'] ?? '';
        
        if (!empty($professionnel_id) && !empty($date_rdv)) {
            $stmt = $pdo->prepare("
                INSERT INTO rendez_vous (utilisateur_id, professionnel_id, date_rdv, notes) 
                VALUES (?, ?, ?, ?)
            ");
            if ($stmt->execute([$_SESSION['user_id'], $professionnel_id, $date_rdv, $notes])) {
                $message = 'Rendez-vous créé avec succès';
                $messageType = 'success';
            }
        }
    } elseif ($action === 'update_status') {
        $rdv_id = $_POST['rdv_id'] ?? '';
        $statut = $_POST['statut'] ?? '';
        
        if (!empty($rdv_id) && !empty($statut)) {
            $stmt = $pdo->prepare("
                UPDATE rendez_vous 
                SET statut = ? 
                WHERE id = ? AND utilisateur_id = ?
            ");
            if ($stmt->execute([$statut, $rdv_id, $_SESSION['user_id']])) {
                $message = 'Statut mis à jour';
                $messageType = 'success';
            }
        }
    } elseif ($action === 'delete') {
        $rdv_id = $_POST['rdv_id'] ?? '';
        
        if (!empty($rdv_id)) {
            $stmt = $pdo->prepare("DELETE FROM rendez_vous WHERE id = ? AND utilisateur_id = ?");
            if ($stmt->execute([$rdv_id, $_SESSION['user_id']])) {
                $message = 'Rendez-vous supprimé';
                $messageType = 'success';
            }
        }
    }
}


$stmt = $pdo->prepare("
    SELECT r.*, p.nom, p.prenom, p.metier, p.ville 
    FROM rendez_vous r
    JOIN professionnels p ON r.professionnel_id = p.id
    WHERE r.utilisateur_id = ?
    ORDER BY r.date_rdv DESC
");
$stmt->execute([$_SESSION['user_id']]);
$rendezVous = $stmt->fetchAll();


$professionnels = $pdo->query("SELECT * FROM professionnels ORDER BY nom")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Rendez-vous</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Gestion des Rendez-vous</h1>
            <div class="user-info">
                <a href="index.php" class="btn btn-logout">← Retour au dashboard</a>
            </div>
        </header>

        <main>
            <section class="full-width">
                <h2>Nouveau Rendez-vous</h2>
                
                <?php if ($message): ?>
                    <div class="message <?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
                <?php endif; ?>

                <form method="POST" class="form-grid">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="form-group">
                        <label for="professionnel_id">Professionnel de santé *</label>
                        <select name="professionnel_id" id="professionnel_id" required>
                            <option value="">Sélectionner...</option>
                            <?php foreach ($professionnels as $pro): ?>
                                <option value="<?= $pro['id'] ?>">
                                    Dr. <?= htmlspecialchars($pro['prenom'] . ' ' . $pro['nom']) ?> - 
                                    <?= htmlspecialchars($pro['metier']) ?> - 
                                    <?= htmlspecialchars($pro['ville']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="date_rdv">Date et heure *</label>
                        <input type="datetime-local" name="date_rdv" id="date_rdv" required>
                    </div>

                    <div class="form-group">
                        <label for="notes">Notes</label>
                        <textarea name="notes" id="notes" rows="3"></textarea>
                    </div>

                    <button type="submit" class="btn-primary">Créer le rendez-vous</button>
                </form>
            </section>

            <section class="full-width">
                <h2>Mes Rendez-vous</h2>
                
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Professionnel</th>
                            <th>Métier</th>
                            <th>Ville</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rendezVous as $rdv): ?>
                            <tr>
                                <td><?= date('d/m/Y H:i', strtotime($rdv['date_rdv'])) ?></td>
                                <td>Dr. <?= htmlspecialchars($rdv['prenom'] . ' ' . $rdv['nom']) ?></td>
                                <td><?= htmlspecialchars($rdv['metier']) ?></td>
                                <td><?= htmlspecialchars($rdv['ville']) ?></td>
                                <td>
                                    <span class="status-badge status-<?= $rdv['statut'] ?>">
                                        <?= htmlspecialchars($rdv['statut']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <?php if ($rdv['statut'] === 'planifié'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="update_status">
                                                <input type="hidden" name="rdv_id" value="<?= $rdv['id'] ?>">
                                                <input type="hidden" name="statut" value="effectué">
                                                <button type="submit" class="btn-small btn-success">Valider</button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <form method="POST" style="display: inline;" 
                                              onsubmit="return confirm('Supprimer ce rendez-vous ?')">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="rdv_id" value="<?= $rdv['id'] ?>">
                                            <button type="submit" class="btn-small btn-danger">Supprimer</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (count($rendezVous) === 0): ?>
                            <tr>
                                <td colspan="6" style="text-align: center; color: #666;">
                                    Aucun rendez-vous enregistré
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>
</body>
</html>