-- Création de la base de données
CREATE DATABASE IF NOT EXISTS visiteur_medical CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE visiteur_medical;

-- 1. Table des utilisateurs (Visiteurs médicaux)
CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    cree_le TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Table des professionnels de santé
CREATE TABLE professionnels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE, -- Utilisé pour le badge dans le tableau
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    metier VARCHAR(100) NOT NULL,
    ville VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- 3. Table des médicaments
CREATE TABLE medicaments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE, -- Utilisé pour le badge dans le tableau
    designation VARCHAR(255) NOT NULL,
    prix DECIMAL(10, 2) NOT NULL
) ENGINE=InnoDB;

-- 4. Table des rendez-vous
CREATE TABLE rendez_vous (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    professionnel_id INT NOT NULL,
    date_rdv DATETIME NOT NULL,
    statut ENUM('planifié', 'effectué', 'annulé') DEFAULT 'planifié',
    notes TEXT,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (professionnel_id) REFERENCES professionnels(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- --- INSERTION DE DONNÉES DE TEST ---

-- Utilisateur : admin / visiteur123 (Le mot de passe doit être haché en PHP via password_hash)
-- Ici, on insère un compte de test. Note : pour le login.php, utilisez password_verify.
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe) VALUES 
('Dupont', 'Jean', 'jean.dupont@exemple.com', '$2y$10$7R8jZ1p9p5e9y8e9y8e9yO7k6j5h4g3f2d1s0a9b8c7'); -- 'visiteur123' haché

-- Professionnels
INSERT INTO professionnels (code, nom, prenom, metier, ville) VALUES 
('PRO001', 'Martin', 'Alice', 'Médecin Généraliste', 'Paris'),
('PRO002', 'Bernard', 'Lucas', 'Cardiologue', 'Lyon'),
('PRO003', 'Dubois', 'Emma', 'Dermatologue', 'Marseille');

-- Médicaments
INSERT INTO medicaments (code, designation, prix) VALUES 
('MED001', 'Paracétamol 500mg', 3.50),
('MED002', 'Ibuprofène 400mg', 5.20),
('MED003', 'Amoxicilline', 12.80);

-- Rendez-vous (Liez à l'utilisateur ID 1)
INSERT INTO rendez_vous (utilisateur_id, professionnel_id, date_rdv, statut) VALUES 
(1, 1, DATE_ADD(NOW(), INTERVAL 1 DAY), 'planifié'),
(1, 2, DATE_ADD(NOW(), INTERVAL 3 DAY), 'planifié'),
(1, 3, DATE_SUB(NOW(), INTERVAL 2 DAY), 'effectué');